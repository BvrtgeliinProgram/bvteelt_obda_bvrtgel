<?php
try
{
	$bdd = new PDO('mysql:host=localhost;  dbname=db_bvteelt;  charset=utf8', 'root', '1');
}
catch(Exception $e)
{
        die('Өгөгдлийн сантай холбогдoход алдаа гарлаа!'.$e->getMessage());
}
