
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../favicon.ico">

        <title>Оюутны бүртгэл</title>
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/ie10-viewport-bug-workaround.css" rel="stylesheet">
         <link href="css/singnin.css" rel="stylesheet">
         <link href="css/style.css" rel="stylesheet">
    <script src="js/ie-emulation-modes-warning.js"></script>
  </head>

  <body>

    <div class="container">

       <form class="form-signin" method="post">
      <h2> <i><legend  style="color: #0000b3">Оюутан бүртгэх хэсэг</legend>
        </i></h2>
        
        <label for="inputEmail" class="sr-only"> </label> 
        <input type="text" name="st_fname" id="inputEmail" class="form-control" placeholder="Оюутны овог" required autofocus>
        </br>
        <label for="inputEmail" class="sr-only"></label>
        <input type="text" name="st_lname" id="inputEmail" class="form-control" placeholder="Оюутны нэр" required autofocus>
</br>
         <label for="inputEmail" class="sr-only"></label>
        <input type="text" name="st_code" id="inputEmail" class="form-control" placeholder="Оюутны код" required autofocus>
</br>
        <label for="inputEmail" class="sr-only"> </label>
        <input type="text" name="st_class" id="inputEmail" class="form-control" placeholder=" Оюутны cуралцаж буй анги" required autofocus>
</br>
        <label for="inputEmail" class="sr-only"></label>
        <input type="text" name="st_sub" id="inputEmail" class="form-control" placeholder="Оюутны судалж буй хичээл" required autofocus>
</br>
      
        <button class="btn btn-primary" type="submit" name="btn-signup">Бүртгэх</button>
                    <a class="btn btn-danger " href="home1.php">Буцах</a>

        
      </form>


    </div> 
  
    <script src="js/ie10-viewport-bug-workaround.js"></script>
  </body>
</html>



<?php 
include("connect.php"); 

mb_internal_encoding('utf-8');
mb_http_input('utf-8');
mb_http_output('utf-8');
mb_language('uni');
mb_regex_encoding('utf-8');
ob_start('mb_output_handler');


    if($_SERVER["REQUEST_METHOD"] == "POST")
    {

 $st_fname =$_POST['st_fname'];
   $st_lname = $_POST['st_lname'];
   $st_code = $_POST['st_code'];
   $st_class = $_POST['st_class'];
    $st_sub = $_POST['st_sub'];
  

       

            
                $query = @mysql_query("INSERT INTO st_register (st_fname, st_lname, st_code, st_class, st_sub ) 
                    VALUES('$st_fname', '$st_lname', '$st_code', '$st_class', '$st_sub')");
                if($query)
                    {
                        ?><script>alert('Амжилттай бүртгэгдлээ. ');</script>
                        <?php
                    }
                    else
                    {
                        ?><script>alert('Бүртгэл амжилтгүй боллоо. Дахин оролдно уу');</script><?php
                    }
    }
?>








