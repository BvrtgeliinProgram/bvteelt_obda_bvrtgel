<?php
require_once('bdd.php');


$sql = "SELECT  st_add FROM st_register ";

$req = $bdd->prepare($sql);
$req->execute();

$st_register = $req->fetchAll();

?>

<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <style type="text/css">
body {
  min-height: 2000px;
  padding-top: 70px;
}

    </style>
    </head>
    <body>

        <nav class="navbar navbar-default navbar-fixed-top">
              <div class="container">
                        <ul class="nav navbar-nav navbar-right">
                        <li><a class= "btn-info "href="reegiisteeer.php"><b>Оюутан нэмж бүртгэх</a></b></li>
                    <li><a class= "btn-warning" href="home1.php"><b>Буцах</b></a></li> 
                    <li><a class= "btn-success "href="logout.php"><b>Гарах</a></b></li>
                      </ul>
                </div>
       </nav>


    <div class="container">
      <div class="jumbotron">
        <?php
        session_start();
        if(!isset($_SESSION['username']))
        {
          header("location: login.php");
        }
include 'connect.php';
$sqlquery = mysql_query("select * from st_register");

echo '<table class="table table-inverse table-bordered table-hover " style="background-color: grey;")>
                        <tr>
                          <td>№</td>
                          <td>Овог</td>
                          <td>Нэр</td>
                          <td>Оюутны код</td>
                          <td>Анги</td>
                          <td>Судлаж буй хичээл</td>
                          <td>Ирц</td>
                          <td>Устгах</td>
                        </tr>';

while ($row = mysql_fetch_array($sqlquery)) 

{
  
                      $st_id = $row['st_id'];
                       $st_fname =$row['st_fname'];
                         $st_lname = $row['st_lname'];
                         $st_code = $row['st_code'];
                         $st_class = $row['st_class'];
                          $st_sub = $row['st_sub'];

	echo "<tr>
                  <td>".$st_id."</td>
                          <td>".$st_fname."</td>
                          <td>".$st_lname."</td>
                          <td>".$st_code."</td>
                          <td>".$st_class."</td>
                          <td>".$st_sub."</td>
                          <td ><a href=st_add.php?st_id=".$st_id.">
                            <select>
                              <option> Ирсэн</option>
                              <option> Чөлөөтэй</option>
                              <option> Өвчтэй</option>
                              <option> Тасалсан</option>        
                            </select></a>
                          </td>
                           <td><a href=delete.php?st_id=".$st_id.">Delete</a></td>
         </tr>";               
}
echo '</table>';

@mysql_close($link);
?>
      </div>
    </div> 
</body>
</html>