<?php
	include "connect.php";

	$st_id = $_GET["st_id"];
	$sql="DELETE FROM st_register WHERE st_id=".$st_id;
	$result=@mysql_query($sql);
	header("location: home.php");
	?>