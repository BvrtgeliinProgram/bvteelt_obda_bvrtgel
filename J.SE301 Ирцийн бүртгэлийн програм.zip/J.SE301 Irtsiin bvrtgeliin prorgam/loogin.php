<?php 

session_start();

if(isset($_SESSION['username']))
        {
          header("location: home1.php");
        }

include("connect.php");

if($_SERVER["REQUEST_METHOD"] == "POST")
{


$_SESSION['username']=addslashes($_POST['username']);
$_SESSION['userpass']=addslashes($_POST['password']);

$sql="SELECT * FROM login WHERE username='".$_SESSION['username']."' and  password='".$_SESSION['userpass']."'";
$result=mysql_query($sql);
$count=mysql_num_rows($result);


if($count==1)
{


  echo 'done';

  header("location: home1.php");

}
else
echo 'Нэвтрэх явцад алдаа гарлаа';
}


 ?>
<!DOCTYPE html>
<html >
  <head>
    <meta charset="UTF-8">
    <title>Нэвтрэх</title>
    
    
    <link rel="stylesheet" href="css/reset.css">
    <link rel="stylesheet" href="css/style1.css">
    
        <script src="js/prefixfree.min.js"></script>

    
  </head>

  <body>

    <div id="login">
  <form id="login_form" method="post">
    <div class="field_container">
      <input type="text" name="username" id="inputEmail" class="form-control" placeholder="Нэвтрэх нэр" required autofocus>
    </div>
    
    <div class="field_container">
      <input type="Password" name="password" id="inputPassword" class="form-control" placeholder="Нууц үг" required>
      <button id="sign_in_button">
        <span class="button_text">Нэвтрэх</span>
      </button>
    </div>

</div> 
    

    
    
  </body>
</html>
