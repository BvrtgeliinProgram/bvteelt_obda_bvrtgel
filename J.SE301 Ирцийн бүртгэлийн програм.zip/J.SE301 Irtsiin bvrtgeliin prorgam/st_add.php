<?php


require_once('bdd.php');

if (isset($_POST['st_add'])){
	
		$st_add = $_POST['st_add'];

	$sql = "INSERT INTO st_register(st_add) values ('$st_add')";
	
	
	echo $sql;
	
	$query = $bdd->prepare( $sql );
	if ($query == false) {
	 print_r($bdd->errorInfo());
	 die ('Erreur prepare');
	}
	$sth = $query->execute();
	if ($sth == false) {
	 print_r($query->errorInfo());
	 die ('Erreur execute');
	}

}
header('Location: '.$_SERVER['HTTP_REFERER']);

	
?>
